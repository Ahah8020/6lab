import React, { useState, useEffect } from 'react';
function App() {
  const [state, setState] = useState({
    spots: [
      { id: 1, isOccupied: false, timeLeft: 0 },
      { id: 2, isOccupied: false, timeLeft: 0 },
      { id: 3, isOccupied: false, timeLeft: 0 },
    ],
    servedCars: 0,
    rejectedCars: 0,
    totalTime: 0,
    occupiedTimeSum: 0,
    income: 0,
    creationCosts: 300,
    maintenanceCosts: 0,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setState((prev) => {
        let newSpots = prev.spots.map((spot) => {
          if (spot.isOccupied) {
            if (spot.timeLeft > 1) {
              return { ...spot, timeLeft: spot.timeLeft - 1 };
            } else {
              return { ...spot, isOccupied: false, timeLeft: 0 };
            }
          }
          return spot;
        });

        const freeSpotIndex = newSpots.findIndex((spot) => !spot.isOccupied);
        let newServedCars = prev.servedCars;
        let newRejectedCars = prev.rejectedCars;

        if (freeSpotIndex !== -1) {
          newSpots[freeSpotIndex] = {
            ...newSpots[freeSpotIndex],
            isOccupied: true,
            timeLeft: Math.floor(Math.random() * 6) + 5,
          };
          newServedCars += 1;
        } else {
          newRejectedCars += 1;
        }

        const currentOccupiedCount = newSpots.filter((s) => s.isOccupied).length;

        const newIncome = newServedCars * 300;
        const newMaintenanceCosts = prev.maintenanceCosts + newSpots.length * 20;

        return {
          ...prev,
          spots: newSpots,
          servedCars: newServedCars,
          rejectedCars: newRejectedCars,
          totalTime: prev.totalTime + 1,
          occupiedTimeSum: prev.occupiedTimeSum + currentOccupiedCount,
          income: newIncome,
          maintenanceCosts: newMaintenanceCosts,
        };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleAddSpot = () => {
    setState((prev) => ({
      ...prev,
      spots: [
        ...prev.spots,
        { id: Date.now(), isOccupied: false, timeLeft: 0 },
      ],
      creationCosts: prev.creationCosts + 100,
    }));
  };

  const totalExpenses = state.creationCosts + state.maintenanceCosts;
  const netProfit = state.income - totalExpenses;
  const totalCars = state.servedCars + state.rejectedCars;
  
  const utilization = state.totalTime === 0 
    ? 0 
    : ((state.occupiedTimeSum / (state.spots.length * state.totalTime)) * 100).toFixed(2);

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>

      {/*Задачи 1-2:*/}
      <div style={{ display: 'flex', gap: '40px', marginBottom: '20px' }}>
        <div>
          <h3>Статистика:</h3>
          <p>Обслужено машин: <b>{state.servedCars}</b></p>
          <p>Отказов: <b>{state.rejectedCars}</b></p>
          <p>Процент загруженности: <b>{utilization}%</b></p>
        </div>
        
        <div>
          <h3>Финансы:</h3>
          <p>Доход: <b>{state.income} ₽</b></p>
          <p>Затраты (создание + содержание): <b>{totalExpenses} ₽</b></p>
          <p style={{ color: netProfit >= 0 ? 'green' : 'red' }}>
            Чистая прибыль: <b>{netProfit} ₽</b>
          </p>
        </div>
      </div>

      {/*Задача 3*/}
      <div style={{ marginBottom: '20px' }}>
        <button onClick={handleAddSpot} style={{ padding: '10px', fontSize: '16px', cursor: 'pointer' }}>
          Добавить парковочное место (-100 ₽)
        </button>
      </div>

      {/*Задача 4*/}
      <h3>Парковочные места (Всего: {state.spots.length})</h3>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
        {state.spots.map((spot, index) => (
          <div 
            key={spot.id} 
            style={{
              width: '120px',
              height: '100px',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: spot.isOccupied ? '#ffcccc' : '#ccffcc',
            }}
          >
            <strong>Место {index + 1}</strong>
            <span>{spot.isOccupied ? 'Занято' : 'Свободно'}</span>
            {spot.isOccupied && <span>({spot.timeLeft} сек)</span>}
          </div>
        ))}
      </div>
    </div>
  );
}
export default App;